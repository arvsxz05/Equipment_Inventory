$(document).ready(function(){
	$('.delete-book').on('click', function(){
		var isbn = $(this).data('isbn');
		var url = '/delete/' + isbn;
		if(confirm('Delete Book?')){
			$.ajax({ 
				url: url,
				type: 'DELETE',
				success: function(result){
					console.log('Deleting book.....');
					window.location.href='/';
				},
				error: function(err){
					console.log(err);
				}
			});
		}
	});

	$('.edit-book').on('click', function(){
		$('#edit-form-title').val($(this).data('title'));
		$('#edit-form-author').val($(this).data('author'));
		$('#edit-form-description').val($(this).data('description'));
		$('#edit-form-isbn').val($(this).data('isbn'));
	});
});