var express = require('express'),
	path = require('path'),
	bodyParser = require('body-parser'),
	cons = require('consolidate'),
	dust = require('dustjs-helpers'),
	pg = require('pg'),
	app = express();

//DB Connect String
var conString = "postgres://postgres:jive1234@localhost/librarydb";

//Assign Dust Engine to .dust Files
app.engine('dust', cons.dust);

//Set Default Ext .dust
app.set('view engine', 'dust');
app.set('views', __dirname + '/views');

//Set Public Folder
app.use(express.static(path.join(__dirname, 'public')));

//Body Parser Middleware
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended:false}));

app.get('/', function(req,res){
	//res.render('index');
	//PG Connect
	pg.connect(conString,function (err, client, done) {
	  if (err){
	  	return console.error('error fetching client from pool', err);
	  }
	  client.query('SELECT * FROM book', function (err, result) {
	    if (err) {
	    	return console.error('error running query', err);
	    }
	    res.render('index', {book: result.rows});
	    done();
	  });
	});
});

app.post('/add', function(req,res){
	//PG Connect
	pg.connect(conString,function (err, client, done) {
	  if (err){
	  	return console.error('error fetching client from pool', err);
	  }
	 client.query("INSERT INTO book(title, author, description) VALUES ($1, $2, $3)",[req.body.title, req.body.author, req.body.description]);
	 done();
	 res.redirect('/');
	});
});

app.delete('/delete/:isbn', function(req, res){
	//PG Connect
	pg.connect(conString,function (err, client, done) {
	  if (err){
	  	return console.error('error fetching client from pool', err);
	  }
	 client.query("DELETE FROM book WHERE isbn = $1",
	 	[req.params.isbn]);
	 done();
	 res.send(200);
	});
})

app.post('/edit', function(req, res){
	//PG Connect
	pg.connect(conString,function (err, client, done) {
	  if (err){
	  	return console.error('error fetching client from pool', err);
	  }
	 client.query("UPDATE book SET title =$1, author=$2, description=$3 WHERE isbn = $4",
	 	[req.body.title, req.body.author, req.body.description, req.body.isbn]);
	 done();
	 res.redirect('/');
	});
})
//Server
app.listen(3000, function(){
	console.log('Serve Started On Port 3000');
});
